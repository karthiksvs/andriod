package kar.login;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public class Success extends Activity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.success);
       }
}